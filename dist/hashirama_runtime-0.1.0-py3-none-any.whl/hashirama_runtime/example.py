def add_two(number):
    return number + 2
